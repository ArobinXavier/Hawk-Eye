import threading
import time

from mqtt_service import start_client
from config_service import create_table
from weightment_service import init
from camera_service import capture_worker   

if __name__ == "__main__":
    create_table()


    # MQTT thread
    mqtt_thread = threading.Thread(
        target=start_client,
        daemon=True
    )
    mqtt_thread.start()

    weight_thread = threading.Thread(
        target=init,
        daemon=True
    )
    weight_thread.start()
    
    capture_worker_thread = threading.Thread(
        target=capture_worker,
        daemon=True
    )
    capture_worker_thread.start()

    # Keep main thread alive
    print("🚀 Application started")
    while True:
        time.sleep(5)
 