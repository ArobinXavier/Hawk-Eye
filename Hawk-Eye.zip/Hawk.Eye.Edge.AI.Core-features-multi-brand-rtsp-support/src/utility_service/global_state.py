from collections import deque

class Globals:
    capture_queue = deque(maxlen=2)
