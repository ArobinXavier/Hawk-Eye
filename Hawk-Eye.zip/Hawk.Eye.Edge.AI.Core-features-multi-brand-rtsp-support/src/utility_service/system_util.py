import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
from camera_service import capture_streams
from gcp_service import upload, download
from ml_service import crop_license_plate
from weightment_service.weightment_socket import get_weight
#import pyautogui
import io
from PIL import Image
import base64
import netifaces
import socket
import re
import time

def restart_app(payload):
    print(f"Restarting the application with payload: {payload}")
    # Logic for restarting the app
    python_executable = sys.executable
    script_path = os.path.abspath(sys.argv[0])
    os.execv(python_executable, [python_executable, script_path])

def reboot(payload):
    print(f"Rebooting the system with payload: {payload}")
    # Logic for rebooting the system
    os.system("sudo reboot")
    
def get_primary_mac():
    for iface in netifaces.interfaces():
        # Skip loopback and docker interfaces
        if iface.startswith('lo') or iface.startswith('docker'):
            continue
        addrs = netifaces.ifaddresses(iface)
        if netifaces.AF_INET in addrs:  # Check for IPv4 address
            mac = addrs[netifaces.AF_LINK][0]['addr']
            return mac
    return None
    
def read_weight_from_socket(ip="192.168.2.1", port=23, timeout=10) -> float:
    print(f"📡 Connecting to weight sensor at {ip}:{port}...")
    def extract_weight_from_packet(packet: str):
        match = re.search(r':\d\s\d{12}', packet)
        if match:
            raw_digits = match.group().split()[1]
            try:
                value = int(raw_digits)
                return value / 1_000_000.0  # Convert to kg
            except ValueError:
                return None
        return None

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            s.connect((ip, port))
            print(f"📡 Connected to {ip}:{port}")

            buffer = ""
            start_time = time.time()

            while time.time() - start_time < timeout:
                try:
                    data = s.recv(1024)
                    if not data:
                        continue

                    buffer += data.decode(errors='ignore')
                    buffer = buffer.replace('\r', '').replace('\n', '')

                    while True:
                        match = re.search(r':\d\s\d{12}', buffer)
                        if match:
                            packet = match.group()
                            weight = extract_weight_from_packet(packet)
                            buffer = buffer[match.end():]  # remove processed part

                            if weight is not None:
                                print(f"✅ Weight: {weight:.3f} kg")
                                return weight
                        else:
                            break
                except socket.timeout:
                    continue
                except Exception as e:
                    print(f"⚠️ Error reading weight: {e}")
                    break

            print("⏰ Timeout: No valid weight received.")
            return 0.0

    except Exception as e:
        print(f"❌ Socket connection error: {e}")
        return 0.0

headers = {
    "uniqueId": get_primary_mac(),
}
print(f"🆔 Device MAC Address: {get_primary_mac()}")

'''
def screenshot(payload):
    print(f"Taking screenshot with payload: {payload}")
    screenshot = pyautogui.screenshot()
    # Save screenshot to a byte buffer
    img_byte_array = io.BytesIO()
    screenshot.save(img_byte_array, format='PNG')
    img_byte_array = img_byte_array.getvalue()

    # Encode the byte array to base64
    img_base64 = base64.b64encode(img_byte_array).decode('utf-8')

    return img_base64
'''

def capture_image(data):
    print("📸 capture image triggered from MQTT...")

    if isinstance(data, str):
        camera_ip = data.strip('"')
    elif isinstance(data, dict):
        camera_ip = data.get("camera_ip")
    else:
        print("Invalid data format")
        return {"status": "NOK", "message": "Invalid data format"}

    if not camera_ip:
        print("Missing camera_ip")
        return {"status": "NOK", "message": "Missing camera_ip"}

    weight = get_weight()

    if weight is None:  
        print("Scale not ready yet")
        return {"status": "NOK", "message": "Scale not ready yet"}

    file_names = capture_streams()
    print(f"Captured files: {file_names}")

    if not file_names:
        return {"status": "NOK", "weight": weight, "urls": []}

    expected_filename = f"camera_{camera_ip}_captured_image.jpg"

    if expected_filename in file_names:
        crop_license_plate(expected_filename)
        if os.path.exists("license_plate.jpg"):
            file_names.append("license_plate.jpg")

    # Upload files
    def upload_file(file):
        return upload(file)

    with ThreadPoolExecutor(max_workers=len(file_names)) as executor:
        urls = [
            f.result()
            for f in as_completed(
                [executor.submit(upload_file, f) for f in file_names]
            )
            if f.result()
        ]

    # Download (optional validation)
    def download_file(url):
        return download(url)

    with ThreadPoolExecutor(max_workers=len(urls)) as executor:
        final_urls = [
            f.result()
            for f in as_completed(
                [executor.submit(download_file, u) for u in urls]
            )
            if f.result()
        ]

    return {"weight": weight, "urls": final_urls}
