from enum import Enum

class Action(str, Enum):
    SET_CONFIG = "set-config"
    STATUS_UPDATE = "status-update"
    CAPTURE_IMAGE = "capture-image"