import os
import sqlite3
import json

DB_FILE = 'config.db'
CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config.json')

# Initialize the database and table
def create_table():
    print('Installation::Create config table if not exists!')
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    conn.commit()
    conn.close()

# Update multiple rows
#configs_to_update = {
    #'server': 'mqtt.newserver.com',
    #'port': '1884',
    #'username': 'newuser',
    #'password': 'newpassword'
#}
def set_config(configs):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    for key, value in configs.items():
        # Convert non-string values to JSON string
        if not isinstance(value, str):
            value = json.dumps(value)
        cursor.execute('''
            INSERT OR REPLACE INTO config (key, value)
            VALUES (?, ?)
        ''', (key, value))
    conn.commit()
    conn.close()
    return {"status": "OK"}

# Get a config value
def get_config(key, default=None):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT value FROM config WHERE key = ?', (key,))
    result = cursor.fetchone()
    print(result)
    conn.close()
    if not result:
        return '[]'
    return result[0] if result else default


def load_default_config():
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Configuration file not found: {CONFIG_FILE}")
        return {}
    except json.JSONDecodeError:
        print(f"Failed to parse configuration file: {CONFIG_FILE}")
        return {}



# Initialize the table (if it doesn't exist)
create_table()

# Example Usage:
#set_config('server', 'mqtt.example.com')
#set_config('port', '1883')

# Retrieving configuration
#server = get_config('server', 'localhost')
#port = get_config('port', 1883)

#print(f"Server: {server}")
#print(f"Port: {port}")
