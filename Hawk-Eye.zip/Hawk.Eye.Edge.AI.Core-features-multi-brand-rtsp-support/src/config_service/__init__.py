# config/__init__.py
from .config_manager import load_default_config, create_table, get_config, set_config
