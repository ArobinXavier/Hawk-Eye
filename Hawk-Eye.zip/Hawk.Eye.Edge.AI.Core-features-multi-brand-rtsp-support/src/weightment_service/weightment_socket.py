import os
import socket
import time
import traceback
import threading

HOST = os.getenv("WEIGHT_SENSOR_IP", "192.168.19.157")
PORT = os.getenv("WEIGHT_SENSOR_PORT", 1701)

RECONNECT_DELAY = 5
READ_DELAY = 2

GLOBAL_WEIGHT = None
WEIGHT_UNIT = None

global_socket = None
scale_ready = False

def debug_print(tag, msg):
    print(f"[Weighment][{tag}] {msg}")
    
def recv_data(sock):
    """Receive available data from socket."""
    try:
        data = sock.recv(4096)
        if data:
            decoded = data.decode(errors="ignore").strip()
            debug_print("RECV", f"Decoded response: {repr(decoded)}")
            return decoded
        return ""
    except socket.timeout:
        return ""
    except Exception as e:
        debug_print("ERROR", f"Exception in recv_data: {e}")
        # traceback.print_exc()
        return ""
    
def send_command(sock, cmd, expect_response=True):
    """Send a command and optionally read the response."""
    try:
        message = cmd.strip() + "\r\n"
        debug_print("SEND", f"Sending command: {repr(message)}")
        sock.sendall(message.encode())

        if expect_response:
            response = recv_data(sock)
            return response
        return ""
    except Exception as e:
        debug_print("ERROR", f"Error sending command '{cmd}': {e}")
        # traceback.print_exc()
        return ""

def connect_to_scale():
    """Establish connection and handle initial greeting."""
    debug_print("DEBUG", f"Connecting to {HOST}:{PORT}")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    sock.connect((HOST, int(PORT)))
    debug_print("INFO", "Connected to IND570.")

    # Read initial banner / greeting
    greeting = recv_data(sock)
    if greeting and "Ready for user" in greeting:
        debug_print("INFO", "Received initial greeting from IND570.")
    else:
        debug_print("WARN", f"No greeting or unexpected response: {greeting}")

    return sock

def login(sock):
    """Send user login command and handle possible password requirement."""
    debug_print("STEP", "Sending 'user admin' login command...")
    response = send_command(sock, "user admin")

    if "Access OK" in response:
        debug_print("INFO", "Login successful - Access OK received.")
        return True
    elif "Enter password" in response:
        debug_print("INFO", "Password required. Sending 'pass 1234'.")
        response = send_command(sock, "pass 1234")
        if "Access OK" in response:
            debug_print("INFO", "Password accepted. Login complete.")
            return True
        else:
            debug_print("ERROR", f"Password rejected: {response}")
    elif "Access" in response:
        debug_print("INFO", f"Access message received: {response}")
        return True
    else:
        debug_print("WARN", f"Unexpected login response: {response}")
    return False


def read_weight(sock, max_retries=5):
    """Read current weight value from IND570 with retry mechanism."""
    debug_print("TRACE", "Entered read_weight()")
    attempt = 0
    while attempt < max_retries:
        attempt += 1
        debug_print("TRACE", f"read_weight loop iteration {attempt}")
        debug_print("STEP", f"Attempt {attempt}: Sending 'read wt0102' command...")
        response = send_command(sock, "read wt0102")
        debug_print("TRACE", f"Raw response received: {repr(response)}")

        if response.startswith("00R"):
            parts = response.split("~")
            debug_print("DEBUG", f"Parsed parts: {parts}")
            if len(parts) >= 3:
                weight = parts[1].strip()
                unit = parts[2].strip()
                debug_print("RESULT", f"Weight = {weight} {unit}")
                debug_print("TRACE", "Exiting read_weight() with SUCCESS")
                return weight, unit
        else:
            debug_print("WARN", f"Unexpected weight response (Attempt {attempt}): {response}")

        time.sleep(0.5)  # short delay before retrying

    debug_print("ERROR", "Failed to get valid weight after max retries.")
    return 0, 0

def weight_reader_loop():
    global GLOBAL_WEIGHT, WEIGHT_UNIT
    debug_print("TRACE", "Entered weight_reader_loop()")

    if not scale_ready or global_socket is None:
        debug_print("TRACE", "Scale not ready or socket is None inside weight_reader_loop")
        GLOBAL_WEIGHT = 0
        WEIGHT_UNIT = 0

    try:
        debug_print("TRACE", "Calling read_weight()")
        weight, unit = read_weight(global_socket)
        debug_print("TRACE", f"read_weight() returned weight={weight}, unit={unit}")
        if weight is not None:
                GLOBAL_WEIGHT = weight
                WEIGHT_UNIT = unit
                debug_print("TRACE",f"Updated GLOBAL_WEIGHT={GLOBAL_WEIGHT}, WEIGHT_UNIT={WEIGHT_UNIT}")

    except Exception as e:
        debug_print("ERROR", f"Weight read failed: {e}")

def get_weight():
    if not scale_ready:
        debug_print("WARN", "Scale not ready")
        return 0
    try:
        return GLOBAL_WEIGHT
    except Exception as e:
        debug_print("ERROR", f"Error reading weight: {e}")
        return 0
 
def init():
    global global_socket, scale_ready
    debug_print("INFO", "Starting IND570 TCP Client with debug output...")

    while True:
        sock = None 
        try:
            sock = connect_to_scale()
            debug_print("TRACE", "Top of init() connection loop")

            if not login(sock):
                debug_print("ERROR", "Login failed. Retrying...")
                sock.close()
                time.sleep(RECONNECT_DELAY)
                continue

            global_socket = sock
            scale_ready = True  
            debug_print("INFO", "Login complete. Socket stored globally.")
            debug_print("TRACE", "Calling weight_reader_loop() ONCE")

            debug_print("TRACE", "Entered KEEP-ALIVE while(True) loop")
            # 🔒 KEEP SOCKET ALIVE
            while True:
                weight_reader_loop()
                debug_print("TRACE",f"Keep-alive loop running | GLOBAL_WEIGHT={GLOBAL_WEIGHT} {WEIGHT_UNIT}")
                time.sleep(3)

        except KeyboardInterrupt:
            debug_print("EXIT", "User interrupted. Exiting program.")
            break

        except Exception as e:
            debug_print("ERROR", f"Connection or runtime error: {e}")
            global_socket = None
            scale_ready = False

            if sock:
                try:
                    sock.close()
                except:
                    pass

            debug_print("INFO", f"Reconnecting in {RECONNECT_DELAY} seconds...")
            time.sleep(RECONNECT_DELAY)