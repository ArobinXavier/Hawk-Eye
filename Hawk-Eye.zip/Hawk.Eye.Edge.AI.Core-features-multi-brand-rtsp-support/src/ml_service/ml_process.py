import os
from ultralytics import YOLO
import cv2

license_model = YOLO("models/license_plate_detector.pt")
# license_model.to('cuda')

def crop_license_plate(file_path):
    car_image = cv2.imread(file_path)
    cropped_image_path = "license_plate.jpg"
    # Delete old file if it exists
    if os.path.exists(cropped_image_path):
        os.remove(cropped_image_path)

    results = license_model(file_path)
    for result in results:
        for box in result.boxes:
            if int(box.cls) == 0:
                xmin, ymin, xmax, ymax = map(int, box.xyxy[0])
                cropped_img = car_image[ymin:ymax, xmin:xmax]
                cv2.imwrite(cropped_image_path, cropped_img)
