import cv2
import json
import subprocess
import platform
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
from config_service import get_config

def ping_camera(ip, timeout=1):
    """
    Cross-platform ping (Linux / JetPack / Windows)
    """
    os_name = platform.system().lower()

    if os_name == "windows":
        command = ["ping", "-n", "1", "-w", str(timeout * 1000), ip]
    else:
        command = ["ping", "-c", "1", "-W", str(timeout), ip]

    try:
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return result.returncode == 0
    except Exception:
        return False

def check_camera_ping(config):
    ip = config["ip"]
    print(f"🔍 Pinging camera: {ip}")

    if ping_camera(ip):
        print(f"✅ Camera {ip} is ONLINE")
        return {"ip": ip, "status": "ONLINE"}
    else:
        print(f"❌ Camera {ip} is OFFLINE")
        return {"ip": ip, "status": "OFFLINE"}


def camera_status():
    """
    Generates camera health report
    """
    camera_configs = json.loads(get_config("camera_config"))
    with ThreadPoolExecutor(max_workers=10) as executor:
        report = list(executor.map(check_camera_ping, camera_configs))
    return report

def capture_camera(config):
    ip, username, password, rtsp_url = config["ip"], config["username"], config["password"], config.get("rtsp_url", None)
    if not rtsp_url:
        rtsp_url = f"rtsp://{username}:{password}@{ip}:554"
    print(f"🎥 Trying camera: {rtsp_url}")

    cap = cv2.VideoCapture(rtsp_url)
    if not cap.isOpened():
        print(f"❌ Failed to connect to camera {ip}")
        return None

    ret, frame = cap.read()
    cap.release()

    if not ret:
        print(f"⚠️ Failed to read frame from camera {ip}")
        return None

    filename = f'camera_{ip}_captured_image.jpg'
    cv2.imwrite(filename, frame)
    return filename

def capture_streams():

    camera_configs = json.loads(get_config("camera_config"))

    timeout_per_camera = 10  # seconds
    captured_files = []
    with ThreadPoolExecutor(max_workers=len(camera_configs)) as executor:
        futures = {executor.submit(capture_camera, cfg): cfg for cfg in camera_configs}
        for future in as_completed(futures):
            config = futures[future]
            try:
                file = future.result(timeout=timeout_per_camera)
                if file:
                    captured_files.append(file)
            except TimeoutError:
                print(f"⏰ Timeout while capturing camera {config['ip']}")
            except Exception as e:
                print(f"❌ Error while capturing camera {config['ip']}: {e}")
    return captured_files