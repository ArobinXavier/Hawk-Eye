import time
import json

def capture_worker():
    from mqtt_service.mqtt_client import publish, TOPIC_ACK
    from utility_service import Globals, capture_image
    print(f"""[capture_worker] Starting capture worker started""")
    while True:
        while len(Globals.capture_queue) > 0:
            message = Globals.capture_queue.popleft()
            request_payload = message.get("payload", {})
            response = capture_image(request_payload)
            message["payload"] = response
            respone_json = json.dumps(message) 
            publish(TOPIC_ACK, respone_json)
            time.sleep(0.01)