import os
import time
import json
import ssl
import paho.mqtt.client as mqtt
from dotenv import load_dotenv

from config_service import set_config
from utility_service import get_primary_mac, capture_image, Globals
from enums.actions import Action 
from enums.edge_status import EdgeStatus   
from camera_service import camera_status

# ------------------------------------------------------------------
# Load ENV
# ------------------------------------------------------------------
load_dotenv()

BROKER = os.getenv("BROKER")
PORT = int(os.getenv("PORT", 1883))
CLIENT_ID_PREFIX = os.getenv("CLIENT_ID_PREFIX", "hawkeye")
USERNAME = os.getenv("USER_NAME")
PASSWORD = os.getenv("PASSWORD")
TOPIC_PREFIX = os.getenv("TOPIC_PREFIX")
TOPIC_DM_PREFIX = os.getenv("TOPIC_DM_PREFIX")
TOPIC_ACK = os.getenv("TOPIC_ACK")
TOPIC_LWT = os.getenv("TOPIC_LWT")
RECONNECT_SEC = int(os.getenv("RECONNECT_SEC", 10))

# Dynamically construct the topic
MAC_ADDRESS = get_primary_mac()
TOPIC = f"{TOPIC_PREFIX}/{MAC_ADDRESS}"
TOPIC_DEVICE_MANAGER = f"{TOPIC_DM_PREFIX}/{MAC_ADDRESS}"

# Singleton instance of the MQTT client
client = None

def get_camera_status(_payload=None):
    """
    Handler for MQTT action: camera-status
    """
    report = camera_status()
    return {
        "cameras": report
    }

def current_status(_payload=None):
    """
    Handler for MQTT action: status-update
    """
    print(f"Request payload: {_payload}")

    return {
        "status": EdgeStatus.ONLINE,
        "mac": MAC_ADDRESS
    }

method_dispatch = {
    "set-config": set_config,
    # "capture-image": capture_image,
    "camera-status": get_camera_status,
    "status-update": current_status
}

# Called when the client receives a CONNACK response from the broker
def on_connect(client, userdata, flags, rc, properties):
    if rc == 0:  # Connection successful
        print(f"[MQTT]Connected with result code {rc}")
        # Subscribe to the topic every time the client connects
        client.subscribe(TOPIC)
        print(f"[MQTT]Subscribed to MQTT topic: {TOPIC}")
        online_message = json.dumps({"topic": TOPIC, "action": Action.STATUS_UPDATE, "payload": {"status": EdgeStatus.ONLINE, "mac": MAC_ADDRESS}})
        publish(TOPIC_ACK, online_message, 1, False)
    else:
        print(f"[MQTT]Failed to connect with result code {rc}")

def on_message(client, userdata, msg):
    try:
        raw_payload = msg.payload.decode()
        #print(f"Message received on topic {msg.topic}: {raw_payload}")
        message = json.loads(raw_payload)
    except Exception as e:
        print(f"[MQTT] Failed to decode JSON payload: {e}")
        return
    print(f"[MQTT]Message received: {message}")
    # Extract info
    method = message.get("action")
    request_payload = message.get("payload", {})

    if method == "capture-image":
        Globals.capture_queue.append(message)
        return

    handler = method_dispatch.get(method)
    if not handler:
        print(f"[MQTT]Unknown action: {method}")
        return {"status": "NOK", "message": "Unknown action"  }
    response_payload = handler(request_payload)
    print(f"[MQTT]response payload::: {response_payload}")

    # Build ack message
    ack_message = {
        # "status": "OK",
        "correlation_id": message.get("correlation_id", '')
    }

    if isinstance(response_payload, dict):
        merged_payload = {**response_payload, **ack_message}
    else:
        merged_payload = ack_message

    message["payload"] = merged_payload

    try:
        response_json = json.dumps(message)
        print(f"[MQTT]Response Message::: {response_json}")
        publish(TOPIC_ACK, response_json, qos=1, retain=False)

    except Exception as e:
        print(f"[MQTT] Failed to publish response: {e}")

# Call when messages needs to be published
def publish(topic, message, qos=1, retain=False):
    print(f"📤 Publish → {topic}: {message}")
    global client
    if client is None:
        print("❌ MQTT client not initialized")
        return
    if not client.is_connected():
        print("⚠️ MQTT client not connected, publish skipped")
        return
    try:
        client.publish(topic, message, qos=qos, retain=retain)
    except Exception as e:
        print(f"❌ MQTT publish failed: {e}")


def start_client():
    print(f"Dynamic Topic Name: {TOPIC}")
    global client
    if client is None:
        # Setup MQTT client
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, f'{CLIENT_ID_PREFIX}-{MAC_ADDRESS}', transport='websockets')
        client.tls_set(cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS)
        # Set username and password for MQTT connection
        client.username_pw_set(USERNAME, PASSWORD)
        print("Username:", USERNAME, "Password:", PASSWORD)
        
        # Set the Last Will and Testament (LWT) message
        LWT_MESSAGE = json.dumps({ "topic": TOPIC, "action": Action.STATUS_UPDATE, "payload": {"status": EdgeStatus.OFFLINE, "mac": MAC_ADDRESS}})
        client.will_set(TOPIC_ACK, payload=LWT_MESSAGE, qos=1, retain=False)

        # Assign event handlers
        client.on_connect = on_connect
        client.on_message = on_message
        # Connect to the MQTT broker
        # Retry logic for initial connection
        while True:
            try:
                print(f"Attempting to connect to MQTT broker at {BROKER}:{PORT}")
                client.connect(BROKER, PORT, keepalive=10)
                break  # Exit the loop if connection is successful
            except OSError as e:
                print(f"Connection failed: {e}. Retrying in {RECONNECT_SEC} seconds...")
                time.sleep(int(RECONNECT_SEC))

        # Start the MQTT loop to listen for incoming messages
        client.loop_forever()  # Use loop_forever to handle automatic reconnections

def get_current_topic():
    return TOPIC

def restart_me():
    print('Sending restart me request to MQTT, this restart will happen over Device manager.')
    request_json = json.dumps({
        "action": "control_service",
        "correlation_id": "",
        "topic": TOPIC_DEVICE_MANAGER,
        "payload": {
            "action": "restart",
            "service_name": "hawk-eye.service"
        }
    })
    publish(TOPIC_DEVICE_MANAGER, request_json)
