import requests
import base64
import cv2
import uuid
import datetime
import mimetypes

FILE_UPLOAD_URL = "https://cloudfileuploadapi.nipponpaint.co.in/api/CloudStorage/CloudFileUpload"
FILE_DOWNLOAD_URL = "https://cloudfileuploadapi.nipponpaint.co.in/api/CloudStorage/CloudFileDownload"

def get_mime_type(extension):
    return mimetypes.types_map.get(extension, 'application/octet-stream')

def upload(file_path):
    try:
        # Prepare file location and file name
        year = str(datetime.datetime.now().year)
        file_location = f"HAWKEYE/Dev/{year}/FileUpload"

        ext = ".jpg"
        current_time_ms = datetime.datetime.now().strftime('%f')[:3]  # Milliseconds
        file_name = f"{uuid.uuid4()}_{current_time_ms}{ext}"
        
        frame = cv2.imread(file_path)
        if frame is None:
            print("⚠️ Could not read image:", file_path)
            return None
        
        resized_frame = cv2.resize(frame, (640, 640), interpolation=cv2.INTER_AREA)
        success, encoded_image = cv2.imencode(
            '.jpg',
            resized_frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), 70]
        )

        if not success:
            raise Exception("Failed to encode image as JPEG")
        
        image_bytes = encoded_image.tobytes()

        # Set up multipart form data
        files = {
            'file': (file_name, image_bytes, get_mime_type(ext))
        }
        data = {
            'Localpath': file_location
        }

        # Make the POST request
        response = requests.post(FILE_UPLOAD_URL, files=files, data=data)

        # Handle response
        if not response.ok:
            raise Exception("File upload failed")

        return response.text

    except Exception as e:
        print("An error occurred while uploading the file")
        return None



def download(image_path):
    try:
        # Remove the file extension like the C# logic
        image_path_without_ext = image_path.rsplit('.', 1)[0]

        multipart_data = {
            'Localpath': (None, image_path)
        }

        # Send POST request with 50s timeout
        response = requests.post(
            FILE_DOWNLOAD_URL,
            files=multipart_data,
            timeout=50
        )

        if response.status_code == 200:
            return response.text
        else:
            print(f"Download failed with status code {response.status_code}")
            return None

    except Exception as e:
        print("An error occurred while downloading the image: %s", e)
        return None

